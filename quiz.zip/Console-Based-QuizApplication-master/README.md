# Console-Based-QuizApplication
Console-Based Quiz Application in Java (To illustrate OOPS concepts)
